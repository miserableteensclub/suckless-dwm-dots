# My Configuration rice Suckless DWM
![](https://github.com/DarlezSec/suckless-dwm-dots/blob/main/pictures/desktop.png)
